# Compilation
Pour compiler, suffit d'utiliser dune build dans le répertoire de ce fichier.
Pareil avec la commande python3 -m http.server
