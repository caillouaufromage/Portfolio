## Projet Biostatistique - Les genes relatifs au cancer du poumon
Objectif : Dans ce projet j'analyserai les donnees d'expression genique du type de cancer du poumon appele Carcinome a Cellules Squameuses afin de trouver le coefficient de correlation pour le gene lorsque le tissu est sain et lorsqu'il est cancereux. Pour cela, je stockerai les differents resultats dans des tableaux excels (disponibles apres compilation) et un graphique en fin de projet.

Data : Les donnees ont ete extraites a partir de deux fichiers texte, l'un pour les tissus cancereux et l'autre pour les tissus sains. Les fichiers lusc-rsem-fpkm-tcga-t_paired.txt et lusc-rsem-fpkm-tcga_paired.txt sont trouvables en cliquant ce lien
